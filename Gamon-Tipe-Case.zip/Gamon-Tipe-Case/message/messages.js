//Toxic
export const bad = [
"bngst"
]
//Toxic
export const dosa = [
"Bokep","bct","Bct","Ngentod","Snge","Sange","Blok","ngewe",
"Ngewe","Ngentd","vcs","Vcs","Coli","coli","colmek","Colmek",
"toket","Toket","oyo","Ah ah ah"
]
//Badword
export const badword = ["asu","Asu","asw","Asw","Ajg","ajg",
"Anjing","anjing","Bajingan","bajingan","Bjingan","bjingan",
"Babi","babi","Bacot","bacot","Bcot","bcot","Cacat","cacat",
"Jancok","jancok","Jncok","jncok","Kontol","kontol","Kntl",
"kntl","KONTOL","kirek","Kirek","Lonte","lonte","Lnte","lnte",
"Memek","memek","Mmek","mmek","Pler","pler","Silet","Silit",
"silit","Silet","Tai","tai","Taek","taek"
]

//Ucapan selamat malem
export const katamalem = [
"Selamat malam","selamat malam","Malam",
"malam","Malem","malem","oyasumi","Oyasumi",
"Oyasuminasai","oyasuminasai","Night","night",
"Good night","good night","Selamat tidur","selamat tidur"
]
//Ucapan terimakasih 
export const thanks = [
"hnk","hanks","akasih","ksh","ksih"
]
//Ucapan selamat siang
export const katasiang = [
"Selamat siang","selamat siang",
"Siang","siang","koniciwa","Koniciwa"
]
//Ucapan selamat sore
export const katasore = [
"Selamat sore","selamat sore","Sore","sore"
]
//Ucapan selamat pagi
export const ohayo = [
"pagi","Pagi","ohayo","Ohayo"
]
//Respon salam kenal
export const ken = [
"salken","Salken","slkn","Slkn","Slken"
]
//Ucapan hai
export const katahai = [
"Halo","halo","Hallo","hallo","Hai","hai","Moshi moshi",
"moshi moshi","Kirara","kirara","Woy","woy","woyy","weh","Weh"
]
//Respon spam bot
export const teksspam = [
"Ups kamu terdeteksi spam",
"Jangan spam kak",
"Jangan spam dong kak, nanti dibanned nie",
"Gak boleh spam kak",
"Wey kak jangan spam ashu"
]
//Respon game salah
export const tekssalah = [
"Salah","Bukan","Salah salah salah","Sualah","Selamat jawaban kamu salah",
"Coba lagi","Hampir","Dikit lagi","Bukan bukan","Yah salah","Yahaha salah",
"Bukan itu","No!","Horeeeee!\nEh salah bukan itu","Asik salah",
"Masih salah 😎","Bukan itu bambang"
]
//Respon orang gblok
export const salam = [
"P","p","p","Pp","pp","P","pP","PP"
]
//Respon link gc private OFF
export const hashira = [
"Link","link","Link grup","Link group","Linkgc","linkgc"
]
//Respon panggilan bot
export const katabot = [
"bot","Bot","bott","Bott"
]
//Respon ara ara
export const katara = [
"ara","Ara","ara ara","Ara ara"
]
//Respon wibu
export const katakawai = [
"yare","yare yare","baka","Baka","gambare","Gambare"
]
//===========================================================//
//GANTI SETERAH LUH
//Ownerin
export const devoloper1 = "6281316643491"
//dile pdf nya 
export const pdf = [
 "application/pdf",
 "application/msword",
 "application/vnd.ms-excel",
"application/vnd.ms-powerpoint",
"application/zip",
"application/x-rar-compressed",
"application/x-tar",
"application/x-7z-compressed",
"application/epub+zip",
"application/json"
]
//Gambar sewa
export const ppSewa = [
"https://telegra.ph/file/ee2de438a198462f0968a.png"
/*
"https://telegra.ph/file/39d61035804d961dbf89f.jpg",
"https://telegra.ph/file/82e2a1573473efce151a0.jpg",
"https://telegra.ph/file/0aad2b2199ce744177989.jpg",
"https://telegra.ph/file/f4f172ca3fb73ee28ee2f.jpg"
*/
]
//Gambar menu
export const ppMenu = [
"https://telegra.ph/file/797842f571d5e3266f05d.jpg"
]
/*
"https://telegra.ph/file/807c0f4a728a9ad35d0d2.jpg",
"https://telegra.ph/file/f2bf1245a28cd0814886c.jpg",
"https://telegra.ph/file/ab01f13caa44e54ed4a6f.jpg",
"https://telegra.ph/file/19d94876f8c4cd88febed.jpg",
"https://telegra.ph/file/2beb8baef0458a0e95b1f.jpg"
]
*/
//Gambar donasi
export const ppDonat = [
"https://telegra.ph/file/95dea4f07783516a63476.jpg"
]
//Gambar rules
export const ppInfo = [
"https://telegra.ph/file/3d704bcc093d516f9bfbe.jpg",
"https://telegra.ph/file/9aa7caf8b2e75ccc9de4b.jpg",
"https://telegra.ph/file/6da2c7774c6f703770855.jpg"
]
//Gambar menfess
export const ppRandom = [
"https://telegra.ph/file/884bccec45b9f97d7ab4f.jpg",
"https://telegra.ph/file/6257afdce98feb5aea57d.jpg",
"https://telegra.ph/file/8f94eeeb12c5a705e107e.jpg",
"https://telegra.ph/file/7a01c9f990b4014396eec.jpg"
]
//Gambar premium
export const ppPrem2 = [
"https://telegra.ph/file/57c0c40ee4f9abf3e542e.jpg",
"https://telegra.ph/file/351adad7a608d059281c2.jpg",
"https://telegra.ph/file/da729e676ec7b4fd3b3ab.jpg"
]
//Gambar premium 
export const ppPrem = [
"https://telegra.ph/file/ec5d0f9490589f4eaacbc.png"
/*
"https://telegra.ph/file/26072a432caa36b6b9fee.jpg",
"https://telegra.ph/file/d8e18c03bf15fe812ca0c.jpg",
"https://telegra.ph/file/c7ba4e79117c91aab094f.jpg"
*/
]
//===========================================================//
//Respon ai
export const kataaii = [
"Cara menghilang","Cara berbicara","Cara boker","Cara putus",
"Cara makan","Cara minum","Cara pintar","Cara goblok","Cara pintar",
"Cara macul","Cara coli","Cara mandi","Cara hilang","Cara membunuh",
"Cacar bernafas","Cara tidur","Cara bangun","Cara ngocok","Cara cebok"
]

























