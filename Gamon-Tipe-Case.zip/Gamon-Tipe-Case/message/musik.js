//AUTO RESPON VN
//JANGAN DI UBAH YEE

export const dmusic = [
"./temp/audio/dj 1.mp3",
"./temp/audio/dj 2.mp3",
"./temp/audio/dj 3.mp3",
"./temp/audio/dj 4.mp3",
"./temp/audio/dj 5.mp3",
"./temp/audio/dj 6.mp3",
"./temp/audio/dj 7.mp3",
"./temp/audio/dj 8.mp3",
"./temp/audio/dj 9.mp3",
"./temp/audio/dj 10.mp3",
"./temp/audio/dj 11.mp3",
"./temp/audio/dj 12.mp3",
]

export const maudio = [
""
]









