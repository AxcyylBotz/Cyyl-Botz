//AUTO RESPON VN
//JANGAN  UBAH YEE


/*

Disini adalah data tempat untuk Voice Note milik si Nina

*/

export const vnBot = [
"./temp/audio/ada apa kak.mp3",
"./temp/audio/ada apa kak1.mp3",
"./temp/audio/iya kak.mp3",
"./temp/audio/kenapa kak.mp3",
"./temp/audio/oyy.mp3",
"./temp/audio/ngomong apaan sih.mp3",
"./temp/audio/lu siapa anjir.mp3"
]

export const vnAra = [
"./temp/audio/ara ara goblok.mp3",
"./temp/audio/ara ara.mp3"
]

export const vnKawai = [
"./temp/audio/gambare.mp3",
"./temp/audio/goblokk.mp3",
"./temp/audio/baka.mp3"
]

export const vnToxic = [
"./temp/audio/dosa pantek.mp3",
"./temp/audio/heeh.mp3",
"./temp/audio/jangan toxic om.mp3"
]

export const vnSpam = [
"./temp/audio/jangan spam ntar gua ewe.mp3"
]

export const vnSalam = [
"./temp/audio/walaikunsalam.mp3"
]

export const vnOwner = [
""
]

export const vnLove = [
""
]















