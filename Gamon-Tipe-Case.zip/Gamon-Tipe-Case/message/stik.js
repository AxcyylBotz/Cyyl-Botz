//AUTO RESPON STIKER
//JANGAN DI UBAH YEE

export const stikSpam = [
"./temp/stick/jangan spam dong.webp",
"./temp/stick/bentar dulu kak.webp",
]

export const stikOtw = [
"./temp/stick/oke tunggu bentar.webp",
]

export const stikThanks = [
"./temp/stick/sama sama kak.webp",
]

export const stikAdmin = [
"./temp/stick/hanya admin kak.webp",
]

export const stikSalam = [
""
]

export const stikOwner = [
"./temp/stick/sticker11.webp",
]

export const stikToxic = [
"./temp/stick/istighfar kak.webp",
]

export const stikNot = [
"./temp/stick/hadeuhh.webp",
"./temp/stick/ketikmenu.webp",
"./temp/stick/sticker06.webp",
"./temp/stick/sticker07.webp",
"./temp/stick/sticker10.webp",
"./temp/stick/sticker11.webp",
"./temp/stick/sticker02.webp",
"./temp/stick/sticker03.webp",
]

export const stikDel = [
"./temp/stick/sticker01.webp"
]






