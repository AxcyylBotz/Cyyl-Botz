import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const version = require("@adiwajshing/baileys/package.json").version 
global.require = require
global.language = "id"
global.nomerOwner = "84528059414"// Ganti sesuka luh
global.nomerOwner2 = "84528059414"// Ganti sesuka luh
global.runWith = "Heroku" // Ganti sesuka luh
global.ownerName = "ˢᴬᴸˢᴴᴼᴾ" // Ganti sesuka luh
global.fakeUrl = ''// Ganti sesuka luh
global.TextT = `ˢᴬᴸˢᴴᴼᴾᴮᵒᵗ` // Ganti sesuka luh
global.botName = "ˢᴬᴸˢᴴᴼᴾᴮᵒᵗ"// Ganti sesuka luh
global.sessionName = "session"
global.setmenu = "livelocation"
//global.docType = ""
global.Qoted = "m"
global.baileysMd = true
global.antiSpam = true
global.fake = botName
global.autoBio = true
global.Console = false
global.publik = false
global.limitCount = 15 // Ganti sesuka luh
global.gcounti = { 'prem' : 60, 'user' : 20 } // Ganti sesuka luh
global.copyright = `© 𝑺𝑨𝑳𝑺𝒉𝒐𝒑ᴮᵒᵗ` // Ganti sesuka luh
global.baileysVersion = `Baileys version ${version}ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ`
global.textT = `Baileys version ${version}ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ`
global.fake1 = "𝑺𝑨𝑳𝑺𝒉𝒐𝒑ᴮᵒᵗ" // Ganti sesuka luh
global.packName = "𝑺𝑨𝑳𝑺𝒉𝒐𝒑ᴮᵒᵗ" // Ganti sesuka luh
global.authorName = "Created By ˢᴬᴸˢᴴᴼᴾᴮᴼᵀ" // Ganti sesuka luh
global.replyType = "web" // Setting => mess,web,web2,quoted 
global.setwelcome = "type11"
global.autoblockcmd = false
global.autoReport = true
global.autoLevel = true
global.multi = true
global.autoSticker = false
global.Intervalmsg = 1000 // Detik
global.app = '•' // Ganti sesuka luh
global.apz = '⎘' // Ganti sesuka luh
global.teksMenu = ''
global.apiflash = '9b9e84dfc18746d4a19d3afe109e9ea4'
global.Dana = '6285811965686'
global.syt = 'https://www.youtube.com/@salsaBoTz-MD'
global.sgc = 'https://chat.whatsapp.com/Fguw4KxsP6qCBm9RfZvHOS'
global.sig = 'https://instagram.com/salsaaj'
global.filestackApi ="" //daftar di filestack

global.ehanzUrl = 'https://telegra.ph/file/59a2583b604f3cb255cb4.jpg'
global.linkUrl = 'https://chat.whatsapp.com/C3zzPfb18BbA7LfRv6ptDz' // Ganti sesuka luh
// Bisa ganti juga => https://wa.me/84528059414
//===========================================================//
//APIKEY NYA KALIAN DAFTAR DULU KALO BLOM PUNYA GA ADA APIKEY FITUR GA BERJALAN LANCAR
global.api = {
ehz: '', //skizo.tech | kalo mau pake api gua izin dulu
angel: 'zenzkey_8bb60993ae', // Apikey Zahwazein
Lol: 'GataDios',
Botcahx: 'Admin',
ApikeyAi: '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',
ApiNobg: 'r1DRrnqgdPT4ceHLUo9m4hTa',
FilestackApi: '',
}
//👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇
//https://www.skizo.tech [ Api ehz ]
//https://www.remove.bg/id/api [ ApiNobg ]
//https://www.filestack.com/ [ FilestackApi ]
//https://platform.openai.com/account/api-keys [ ApikeyAi ]
//===========================================================//





