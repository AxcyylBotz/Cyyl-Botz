## SC BKT WA CAMPURAN FROM OFFICIALDITTAZ & ARYAXYZ 
<img src="https://telegra.ph/file/48702ca79b373b1f0e35c.jpg" alt="YOGI" width="360" />

---

## Information
> Hashira Bot adalah bot yang awalnya memakai base dari [Amelia-Botz](https://github.com/officialdittaz/Amelia-Botz/) .
> Jika kamu menemukan semacam bug, harap untuk dimaklumi sementara

## Connect With Me
[`Klik Disini`](https://wa.me/6281316643491)

## Bugs and Tester
* Jika kamu menemukan bug atau error
* Info Lebih Lanjut, Chat [Owner Ehanz](https://wa.me/6281316643491)

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip) (for sticker command)

## Heroku Buildpack
```bash
 heroku/nodejs
 https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
 https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## Donate
- [Saweria](https://)
- [Dana](http://)
- [Ovo](https://)
- [Gopay](https://)

# Official Group
- [Hashira Botz](https://chat.whatsapp.com/Co1dxN1z7YGAJXxKter3Bn)

# Thanks to
 <a href="https://github.com/hexagonz"><img src="https://https://github.com/hexagonz.png?size=100" width="100" height="100"></a> | [![FERDIZ](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz-afk) | [![RASHID](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz) 
---|---|---
[Adiwajshing](https://github.com/adiwajshing/Baileys)  | [Hexagonz](https://github.com/hexagonz) |
Owner of Baileys | Constributor | Constributor


 <a href="https://github.com/hexagonz"><img src="https://https://github.com/hexagonz.png?size=100" width="100" height="100"></a> | [![FERDIZ](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz-afk) | [![RASHID](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz) 
 ---|---|---
[Official Dittaz](https://github.com/officialdittaz)| [YogiPw](https://github.com/yogipw) | 
Owner Amelia - Botz | For Help | 

##
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`Hexagonz`](https://github.com/hexagonz)
* [`Yogipw`](https://github.com/yogipw)

> Run Pake PM@ + COLOR

> run = "FORCE_COLOR=1 pm2 start index.js && pm2 save && pm2 save && pm2 logs --raw"

> Hapus Node Modules : rm -r node_modules

> Edit Node Modules : mv node_modules edit

> Hapus Session : rm -rf session

> Edit Owner Dll Di settings.js
 Untuk Apikey Jika Blom Ada Kalian Bisa Daftar Sendiri Yah



